export interface Question {
  id: string;
  title: string;
  subject: string;
  questionText: string;
  modelAnswer: string;
  maxPoints: number;
  rubricCriteria: string[]; // key concepts required in the response
  instructionalStrategy?: string; // Teacher's adjusted strategy based on class performance
  strategyUpdatedAt?: string;
}

export interface EvaluationResult {
  score: number; // Final score (0 - maxPoints)
  semanticSimilarityScore: number; // 0 - 100% semantic overlap with model answer
  conceptCoverage: { concept: string; score: number; feedback: string }[]; // Specific rubric scores
  strengths: string[];
  weaknesses: string[];
  constructiveFeedback: string;
  grammarScore: number; // 0 - 100
  evaluatedBy: 'Gemini 3.5-Flash';
  evaluatedAt: string;
}

export interface Submission {
  id: string;
  questionId: string;
  studentName: string;
  studentRoll: string;
  answerText: string;
  submittedAt: string;
  evaluation?: EvaluationResult;
}

export interface ClassPerformanceTrend {
  questionId: string;
  questionTitle: string;
  subject: string;
  averageScore: number;
  averageSemanticSimilarity: number;
  totalSubmissions: number;
  gradedCount: number;
  conceptAverages: { concept: string; averageScore: number }[]; // Average score per rubric item
}
