import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  BarChart3, 
  BookOpen, 
  Award, 
  Sparkles, 
  AlertCircle, 
  CheckCircle2, 
  X,
  FileText
} from "lucide-react";
import DashboardOverview from "./components/DashboardOverview";
import EvaluationWorkbench from "./components/EvaluationWorkbench";
import QuestionManager from "./components/QuestionManager";
import { Question, Submission } from "./types";

interface Toast {
  id: string;
  type: "success" | "error" | "info";
  message: string;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<string>("overview");
  const [questions, setQuestions] = useState<Question[]>([]);
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [activeSubId, setActiveSubId] = useState<string | undefined>(undefined);
  const [activeQId, setActiveQId] = useState<string | undefined>(undefined);

  // Load Initial Data from Backend
  const loadData = async () => {
    try {
      setIsLoading(true);
      const [questionsRes, submissionsRes, statsRes] = await Promise.all([
        fetch("/api/questions"),
        fetch("/api/submissions"),
        fetch("/api/dashboard/stats")
      ]);

      if (!questionsRes.ok || !submissionsRes.ok || !statsRes.ok) {
        throw new Error("Failed to load full application datasets from server.");
      }

      const qData = await questionsRes.json();
      const sData = await submissionsRes.json();
      const stData = await statsRes.json();

      setQuestions(qData);
      setSubmissions(sData);
      setStats(stData);
    } catch (err: any) {
      console.error(err);
      addToast("error", err.message || "Failed to load academic records.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Toast notifications manager
  const addToast = (type: "success" | "error" | "info", message: string) => {
    const id = Date.now().toString();
    setToasts(prev => [...prev, { id, type, message }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  // Navigations from dashboard cards
  const handleNavigateToTab = (tab: string, activeId?: string) => {
    setActiveTab(tab);
    if (tab === "workbench") {
      setActiveSubId(activeId);
    } else if (tab === "questions") {
      setActiveQId(activeId);
    }
  };

  // API Call: Add Question
  const handleAddQuestion = async (newQ: Omit<Question, "id">) => {
    try {
      const res = await fetch("/api/questions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newQ)
      });
      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Failed to save question.");
      }
      const created = await res.json();
      setQuestions(prev => [...prev, created]);
      addToast("success", `Question "${created.title}" successfully added with rubrics.`);
      
      // Reload stats to reflect new question count
      const statsRes = await fetch("/api/dashboard/stats");
      if (statsRes.ok) setStats(await statsRes.json());

      return created;
    } catch (err: any) {
      addToast("error", err.message);
      throw err;
    }
  };

  // API Call: Add Submission
  const handleAddSubmission = async (newSub: { questionId: string; studentName: string; studentRoll: string; answerText: string }) => {
    try {
      const res = await fetch("/api/submissions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newSub)
      });
      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Failed to upload answer response.");
      }
      const created = await res.json();
      setSubmissions(prev => [...prev, created]);
      addToast("success", `Student response for ${created.studentName} received and queued.`);
      
      // Reload stats
      const statsRes = await fetch("/api/dashboard/stats");
      if (statsRes.ok) setStats(await statsRes.json());

      return created;
    } catch (err: any) {
      addToast("error", err.message);
      throw err;
    }
  };

  // API Call: Evaluate Student Response
  const handleEvaluateSubmission = async (id: string) => {
    try {
      const res = await fetch(`/api/submissions/${id}/evaluate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" }
      });
      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Evaluation failed.");
      }
      const evaluation = await res.json();
      
      // Update submissions list state
      setSubmissions(prev => prev.map(s => s.id === id ? { ...s, evaluation } : s));
      addToast("success", `Evaluation Complete: Scored ${evaluation.score} pts with ${evaluation.semanticSimilarityScore}% semantic match!`);

      // Reload stats to reflect new average grades and trends
      const statsRes = await fetch("/api/dashboard/stats");
      if (statsRes.ok) setStats(await statsRes.json());

      return evaluation;
    } catch (err: any) {
      addToast("error", err.message);
      throw err;
    }
  };

  // API Call: Generate Instructional Strategy Advice
  const handleGenerateStrategy = async (id: string) => {
    try {
      const res = await fetch(`/api/questions/${id}/strategy`, {
        method: "POST",
        headers: { "Content-Type": "application/json" }
      });
      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Failed to generate strategies.");
      }
      const result = await res.json();
      
      // Update questions list state
      setQuestions(prev => prev.map(q => q.id === id ? { 
        ...q, 
        instructionalStrategy: result.instructionalStrategy,
        strategyUpdatedAt: result.strategyUpdatedAt
      } : q));

      addToast("success", "Instructional Strategy recommendations generated successfully.");
      
      // Reload stats to fetch updated trends
      const statsRes = await fetch("/api/dashboard/stats");
      if (statsRes.ok) setStats(await statsRes.json());

      return result;
    } catch (err: any) {
      addToast("error", err.message);
      throw err;
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center space-y-4">
        <div className="relative flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
          <Sparkles className="h-5 w-5 text-indigo-500 absolute animate-pulse" />
        </div>
        <div className="text-center">
          <h3 className="text-sm font-bold text-slate-800">Initializing Descriptive Evaluator</h3>
          <p className="text-[11px] text-slate-400 mt-1">Seeding examination rubrics and loading student performance trends...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 antialiased flex flex-col">
      {/* GLOBAL TOAST OVERLAYS */}
      <div className="fixed top-5 right-5 z-50 space-y-2 max-w-sm w-full pointer-events-none">
        <AnimatePresence>
          {toasts.map((t) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, x: 20, y: -10 }}
              animate={{ opacity: 1, x: 0, y: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="pointer-events-auto bg-white border border-slate-200 shadow-xl rounded-xl p-4 flex items-start gap-3"
            >
              {t.type === "success" ? (
                <CheckCircle2 className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="h-5 w-5 text-rose-500 shrink-0 mt-0.5" />
              )}
              <div className="flex-1">
                <p className="text-xs font-bold text-slate-900">
                  {t.type === "success" ? "Operation Successful" : "System Error"}
                </p>
                <p className="text-[11px] text-slate-500 mt-1 leading-normal">{t.message}</p>
              </div>
              <button 
                onClick={() => removeToast(t.id)}
                className="p-0.5 hover:bg-slate-50 text-slate-400 hover:text-slate-600 rounded transition-all"
              >
                <X className="h-4 w-4" />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* HEADER HERO AREA */}
      <header className="bg-white border-b border-slate-200 shadow-sm z-10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-indigo-600 rounded flex items-center justify-center shadow-sm shrink-0">
              <div className="w-4.5 h-4.5 border-2 border-white rotate-45"></div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-bold tracking-tight text-slate-900">
                  LinguistAI <span className="text-slate-400 font-normal ml-1 text-xs">Answer Evaluation System</span>
                </h1>
                <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-700 tracking-wider">ARES PRO v3.5</span>
              </div>
              <p className="text-[10px] text-slate-500 font-medium">Semantic Similarity Assessment & Automated Grading Diagnostics for Educators.</p>
            </div>
          </div>

          {/* Tab Navigation */}
          <nav className="flex space-x-1 bg-slate-100 p-1 rounded-xl self-start md:self-auto border border-slate-200/50">
            {[
              { id: "overview", label: "Dashboard", icon: BarChart3 },
              { id: "workbench", label: "Evaluator", icon: Award },
              { id: "questions", label: "Questions & Rubrics", icon: BookOpen }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id);
                  // Reset temporary parameter states
                  if (tab.id !== "workbench") setActiveSubId(undefined);
                  if (tab.id !== "questions") setActiveQId(undefined);
                }}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                  activeTab === tab.id 
                    ? "bg-white text-indigo-600 shadow-sm" 
                    : "text-slate-500 hover:text-slate-800 hover:bg-white/50"
                }`}
              >
                <tab.icon className="h-3.5 w-3.5" />
                {tab.label}
              </button>
            ))}
          </nav>
        </div>
      </header>

      {/* MAIN CONTENT AREA */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-6 py-8">
        <AnimatePresence mode="wait">
          {activeTab === "overview" && (
            <motion.div
              key="overview-pane"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              <DashboardOverview 
                stats={stats} 
                submissions={submissions} 
                questions={questions}
                onNavigateToTab={handleNavigateToTab}
              />
            </motion.div>
          )}

          {activeTab === "workbench" && (
            <motion.div
              key="workbench-pane"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              <EvaluationWorkbench 
                questions={questions}
                submissions={submissions}
                onAddSubmission={handleAddSubmission}
                onEvaluateSubmission={handleEvaluateSubmission}
                activeSubmissionId={activeSubId}
              />
            </motion.div>
          )}

          {activeTab === "questions" && (
            <motion.div
              key="questions-pane"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              <QuestionManager 
                questions={questions}
                submissions={submissions}
                onAddQuestion={handleAddQuestion}
                onGenerateStrategy={handleGenerateStrategy}
                initialSelectedQuestionId={activeQId}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* FOOTER */}
      <footer className="bg-white border-t border-slate-200 py-6 mt-12">
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <p>© 2026 Academic Evaluation Systems (ARES). Designed to support educational institutions and reduce manual grading effort.</p>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5 font-mono text-[10px] bg-slate-50 border border-slate-100 px-2 py-1 rounded">
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
              FastAPI Context Mimic (Express)
            </span>
            <span className="flex items-center gap-1.5 font-mono text-[10px] bg-slate-50 border border-slate-100 px-2 py-1 rounded">
              NLP Engine: Gemini 3.5-Flash
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}
