import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Plus, 
  Trash, 
  Sparkles, 
  BookOpen, 
  Clipboard, 
  ArrowRight, 
  BookOpenCheck,
  Award,
  Calendar,
  Layers,
  FileSpreadsheet
} from "lucide-react";

interface Question {
  id: string;
  title: string;
  subject: string;
  questionText: string;
  modelAnswer: string;
  maxPoints: number;
  rubricCriteria: string[];
  instructionalStrategy?: string;
  strategyUpdatedAt?: string;
}

interface QuestionManagerProps {
  questions: Question[];
  submissions: any[];
  onAddQuestion: (question: Omit<Question, "id">) => Promise<any>;
  onGenerateStrategy: (id: string) => Promise<any>;
  initialSelectedQuestionId?: string;
}

export default function QuestionManager({ 
  questions, 
  submissions, 
  onAddQuestion, 
  onGenerateStrategy,
  initialSelectedQuestionId 
}: QuestionManagerProps) {
  const [selectedQId, setSelectedQId] = useState<string | null>(initialSelectedQuestionId || (questions.length > 0 ? questions[0].id : null));
  const [showAddForm, setShowAddForm] = useState(false);
  const [isGeneratingStrategy, setIsGeneratingStrategy] = useState(false);

  // Form Fields
  const [newTitle, setNewTitle] = useState("");
  const [newSubject, setNewSubject] = useState("");
  const [newQText, setNewQText] = useState("");
  const [newModelAns, setNewModelAns] = useState("");
  const [newMaxPoints, setNewMaxPoints] = useState(10);
  const [newRubricString, setNewRubricString] = useState(""); // comma separated

  const selectedQ = questions.find(q => q.id === selectedQId) || (questions.length > 0 ? questions[0] : null);
  const relatedSubmissions = selectedQ ? submissions.filter(s => s.questionId === selectedQ.id) : [];
  const gradedCount = relatedSubmissions.filter(s => s.evaluation).length;

  useEffect(() => {
    if (initialSelectedQuestionId) {
      setSelectedQId(initialSelectedQuestionId);
    }
  }, [initialSelectedQuestionId]);

  const handleCreateQuestion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle || !newSubject || !newQText || !newModelAns || !newRubricString) return;

    const rubricCriteria = newRubricString
      .split("\n")
      .map(item => item.trim())
      .filter(Boolean);

    try {
      const created = await onAddQuestion({
        title: newTitle,
        subject: newSubject,
        questionText: newQText,
        modelAnswer: newModelAns,
        maxPoints: Number(newMaxPoints),
        rubricCriteria
      });
      setSelectedQId(created.id);
      setShowAddForm(false);
      // Reset
      setNewTitle("");
      setNewSubject("");
      setNewQText("");
      setNewModelAns("");
      setNewMaxPoints(10);
      setNewRubricString("");
    } catch (err) {
      console.error(err);
    }
  };

  const handleTriggerStrategy = async () => {
    if (!selectedQ) return;
    setIsGeneratingStrategy(true);
    try {
      await onGenerateStrategy(selectedQ.id);
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingStrategy(false);
    }
  };

  // Render Strategic recommendations in formatted HTML
  const renderStrategyMarkdown = (md: string) => {
    if (!md) return <p className="text-slate-400 italic text-xs">No instructional adjustments computed yet. Grade student submissions then run the analysis!</p>;
    
    return md.split("\n").map((line, index) => {
      const trimmed = line.trim();
      
      // Headers
      if (trimmed.startsWith("###")) {
        return <h4 key={index} className="text-xs font-bold text-slate-800 uppercase tracking-wide mt-4 mb-2 first:mt-0">{trimmed.replace(/^###\s*/, "")}</h4>;
      }
      if (trimmed.startsWith("##")) {
        return <h3 key={index} className="text-sm font-bold text-indigo-900 mt-5 mb-3 border-b border-indigo-100 pb-1 first:mt-0">{trimmed.replace(/^##\s*/, "")}</h3>;
      }
      if (trimmed.startsWith("#")) {
        return <h2 key={index} className="text-base font-bold text-slate-900 mt-6 mb-4">{trimmed.replace(/^#\s*/, "")}</h2>;
      }
      
      // Bullets
      if (trimmed.startsWith("-") || trimmed.startsWith("*")) {
        const text = trimmed.replace(/^[-*]\s*/, "");
        // Check for bold prefixes e.g. **Title**: text
        const boldMatch = text.match(/^\*\*(.*?)\*\*:(.*)/);
        if (boldMatch) {
          return (
            <li key={index} className="ml-4 list-disc text-xs text-slate-600 mb-1.5 leading-relaxed">
              <strong className="text-slate-800">{boldMatch[1]}:</strong>{boldMatch[2]}
            </li>
          );
        }
        return (
          <li key={index} className="ml-4 list-disc text-xs text-slate-600 mb-1.5 leading-relaxed">
            {text}
          </li>
        );
      }

      // Normal text
      if (trimmed) {
        // Check bold text in line
        let formatted = trimmed;
        // Simple replace for **text**
        formatted = formatted.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");
        return <p key={index} className="text-xs text-slate-600 mb-2 leading-relaxed" dangerouslySetInnerHTML={{ __html: formatted }}></p>;
      }
      
      return <div key={index} className="h-1"></div>;
    });
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start" id="question-manager">
      {/* LEFT COLUMN: LIST OF QUESTIONS */}
      <div className="lg:col-span-4 bg-white rounded-xl border border-slate-200 shadow-sm p-4 h-[750px] flex flex-col justify-between">
        <div className="space-y-4 flex-1 overflow-hidden flex flex-col">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
              <span className="w-1.5 h-3 bg-indigo-600 rounded-sm"></span>
              Questions & Rubrics
            </h3>
            <button 
              onClick={() => setShowAddForm(true)}
              className="flex items-center gap-1 text-[11px] font-bold px-2.5 py-1.5 bg-indigo-600 text-white rounded hover:bg-indigo-700 transition-all uppercase tracking-wider"
            >
              <Plus className="h-3 w-3" />
              Add Question
            </button>
          </div>

          <div className="flex-1 overflow-y-auto space-y-2 pr-1 mt-2">
            {questions.map((q) => {
              const isSelected = q.id === selectedQId;
              const subs = submissions.filter(s => s.questionId === q.id);
              const graded = subs.filter(s => s.evaluation).length;
              
              return (
                <button
                  key={q.id}
                  onClick={() => setSelectedQId(q.id)}
                  className={`w-full text-left p-4 rounded-lg border transition-all duration-200 ${
                    isSelected 
                      ? "bg-slate-900 border-slate-900 text-white shadow-md" 
                      : "bg-slate-50/50 hover:bg-slate-50 border-slate-200 text-slate-800"
                  }`}
                >
                  <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wider ${
                    isSelected ? "bg-slate-800 text-slate-300 border border-slate-800/50" : "bg-slate-100 text-slate-500 border border-slate-200"
                  }`}>
                    {q.subject}
                  </span>
                  
                  <h4 className={`text-xs font-bold mt-2 truncate ${isSelected ? "text-white" : "text-slate-900"}`}>
                    {q.title}
                  </h4>
                  
                  <p className={`text-[11px] line-clamp-2 mt-1 ${isSelected ? "text-slate-300" : "text-slate-500"} font-medium`}>
                    {q.questionText}
                  </p>

                  <div className="flex items-center justify-between text-[10px] mt-3 pt-2.5 border-t border-slate-100/10 text-slate-400">
                    <span className="font-semibold">{q.rubricCriteria.length} Rubrics</span>
                    <span className="font-semibold">{subs.length} Ans ({graded} Graded)</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* RIGHT COLUMN: QUESTION DETAILS & ADVANCED PEDAGOGY / REMEDIATION CENTER */}
      <div className="lg:col-span-8 space-y-6">
        {selectedQ ? (
          <div className="space-y-6">
            
            {/* Question Details Block */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-5">
              <div className="flex items-start justify-between border-b border-slate-100 pb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold text-indigo-650 bg-indigo-50 border border-indigo-100 px-2.5 py-1 rounded-full uppercase tracking-wider">
                      {selectedQ.subject}
                    </span>
                    <span className="text-[10px] font-mono font-bold text-slate-400">ID: {selectedQ.id}</span>
                  </div>
                  <h3 className="text-sm font-bold text-slate-900 mt-2">{selectedQ.title}</h3>
                </div>
                <div className="text-right">
                  <span className="text-[9px] text-slate-400 block font-bold uppercase tracking-wider">Max Points</span>
                  <span className="text-base font-bold text-indigo-600 bg-indigo-50 border border-indigo-100 px-2.5 py-1 rounded-md mt-1 inline-block font-mono">{selectedQ.maxPoints} pts</span>
                </div>
              </div>

              {/* Text Blocks */}
              <div className="space-y-4">
                <div className="space-y-1.5">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Question Prompt</span>
                  <p className="text-xs text-slate-700 leading-relaxed p-4 rounded-lg bg-slate-50/50 border border-slate-150 font-medium">{selectedQ.questionText}</p>
                </div>

                <div className="space-y-1.5">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Evaluation Reference (Model Answer)</span>
                  <p className="text-xs text-slate-700 leading-relaxed p-4 rounded-lg bg-slate-50/50 border border-slate-150 font-medium">{selectedQ.modelAnswer}</p>
                </div>
              </div>

              {/* Rubric Points List */}
              <div className="space-y-2 pt-2">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Structured Rubric Criteria</span>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                  {selectedQ.rubricCriteria.map((rc, idx) => (
                    <div key={idx} className="flex items-start gap-2.5 p-3 rounded-lg border border-slate-150 bg-slate-50/50">
                      <span className="h-5 w-5 rounded-full bg-indigo-50 text-indigo-600 border border-indigo-150 flex items-center justify-center text-[10px] font-bold font-mono shrink-0">
                        {idx + 1}
                      </span>
                      <span className="text-xs text-slate-600 leading-normal font-medium">{rc}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* AI PEDAGOGICAL ADVISORY & REMEDIATION PANEL (Crucial User Prompt requirement) */}
            <div className="bg-slate-900 text-slate-100 rounded-xl border border-slate-800 shadow-2xl p-6 space-y-5 relative overflow-hidden">
              {/* Decorative geometric circle */}
              <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
                <div className="w-48 h-48 border-[12px] border-white rounded-full"></div>
              </div>

              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4 relative z-10">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-lg bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                    <Sparkles className="h-5 w-5 animate-pulse" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                      Pedagogical Advisory & Remediation
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5 font-medium">Automated instructional strategy adjustments based on collective student performance trends.</p>
                  </div>
                </div>

                <button
                  onClick={handleTriggerStrategy}
                  disabled={isGeneratingStrategy || gradedCount === 0}
                  className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded shadow-sm disabled:opacity-45 disabled:cursor-not-allowed transition-all relative z-10"
                >
                  <Sparkles className="h-3.5 w-3.5" />
                  {isGeneratingStrategy ? "Analyzing Gaps..." : "Analyze Class Trends"}
                </button>
              </div>

              {/* Trend summary */}
              <div className="grid grid-cols-3 gap-4 p-4 rounded-lg bg-slate-850 border border-slate-800 text-center relative z-10 font-mono">
                <div>
                  <span className="text-[9px] text-slate-400 block font-bold uppercase tracking-wider">Class Answers</span>
                  <span className="text-lg font-bold text-white mt-1 block">{relatedSubmissions.length}</span>
                </div>
                <div>
                  <span className="text-[9px] text-slate-400 block font-bold uppercase tracking-wider">Graded Base</span>
                  <span className="text-lg font-bold text-white mt-1 block">{gradedCount}</span>
                </div>
                <div>
                  <span className="text-[9px] text-slate-400 block font-bold uppercase tracking-wider">Analysis Status</span>
                  {selectedQ.instructionalStrategy ? (
                    <span className="text-[9px] font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 mt-2 inline-block border border-emerald-500/20 uppercase tracking-wider">Active</span>
                  ) : (
                    <span className="text-[9px] font-bold px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 mt-2 inline-block border border-amber-500/20 uppercase tracking-wider">Pending</span>
                  )}
                </div>
              </div>

              {/* Strategic Advice Markdown Box */}
              <div className="bg-white text-slate-800 p-6 rounded-lg border border-slate-200 shadow-inner max-h-[400px] overflow-y-auto relative z-10 font-medium">
                <AnimatePresence mode="wait">
                  {isGeneratingStrategy ? (
                    <motion.div 
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="py-16 flex flex-col items-center justify-center space-y-4 text-center"
                    >
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-650"></div>
                      <div className="space-y-1 text-slate-500">
                        <p className="text-xs font-bold uppercase tracking-wider text-slate-700">Synthesizing Diagnostics...</p>
                        <p className="text-[10px] font-medium text-slate-400">Analyzing rubric concept coverage and formulating tailored remedial class interventions...</p>
                      </div>
                    </motion.div>
                  ) : (
                    <motion.div 
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="space-y-2 select-text text-slate-700"
                    >
                      {renderStrategyMarkdown(selectedQ.instructionalStrategy || "")}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {selectedQ.strategyUpdatedAt && (
                <div className="flex items-center justify-between text-[10px] text-slate-500 mt-2 font-medium relative z-10">
                  <span>Methodology: Pedagogy-Expert LLM Adjustments</span>
                  <span>Strategy updated on {new Date(selectedQ.strategyUpdatedAt).toLocaleString()}</span>
                </div>
              )}
            </div>

          </div>
        ) : (
          <div className="bg-white rounded-xl border border-slate-200 p-12 text-center text-slate-400 font-medium">
            No questions loaded. Add a descriptive question to get started.
          </div>
        )}
      </div>

      {/* CREATE QUESTION MODAL FORM */}
      <AnimatePresence>
        {showAddForm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-xl border border-slate-200 shadow-2xl max-w-xl w-full overflow-hidden flex flex-col"
            >
              <div className="p-6 border-b border-slate-150 flex items-center justify-between bg-slate-50">
                <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">Add Descriptive Exam Question</h3>
                <button 
                  onClick={() => setShowAddForm(false)}
                  className="text-xs text-slate-400 hover:text-slate-600 font-bold uppercase tracking-wider"
                >
                  Cancel
                </button>
              </div>
              
              <form onSubmit={handleCreateQuestion} className="p-6 space-y-4 flex-1 overflow-y-auto max-h-[580px]">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Question Title / Topic</label>
                    <input 
                      type="text"
                      placeholder="e.g. Heuristic Search Algorithms"
                      required
                      value={newTitle}
                      onChange={(e) => setNewTitle(e.target.value)}
                      className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/10 focus:border-indigo-500"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Subject Discipline</label>
                    <input 
                      type="text"
                      placeholder="e.g. Artificial Intelligence"
                      required
                      value={newSubject}
                      onChange={(e) => setNewSubject(e.target.value)}
                      className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/10 focus:border-indigo-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-1 col-span-3">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Max Points</label>
                    <input 
                      type="number"
                      min={1}
                      max={100}
                      required
                      value={newMaxPoints}
                      onChange={(e) => setNewMaxPoints(Number(e.target.value))}
                      className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/10 focus:border-indigo-500 font-mono"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Descriptive Question Prompt Text</label>
                  <textarea
                    rows={3}
                    required
                    placeholder="Enter the full exam question prompt..."
                    value={newQText}
                    onChange={(e) => setNewQText(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/10 focus:border-indigo-500 leading-relaxed font-sans"
                  ></textarea>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Model Answer (Benchmark Reference)</label>
                  <textarea
                    rows={4}
                    required
                    placeholder="Enter the ideal model answer containing the required technical details and keyword benchmarks..."
                    value={newModelAns}
                    onChange={(e) => setNewModelAns(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/10 focus:border-indigo-500 leading-relaxed font-sans"
                  ></textarea>
                </div>

                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Evaluation Rubric Items (One per line)</label>
                    <span className="text-[10px] text-slate-400 font-semibold">At least 3 core points</span>
                  </div>
                  <textarea
                    rows={4}
                    required
                    placeholder="Describe A* heuristic and admissibility requirements&#10;Explain path cost function f(n) = g(n) + h(n)&#10;Define consistency of heuristic function..."
                    value={newRubricString}
                    onChange={(e) => setNewRubricString(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/10 focus:border-indigo-500 leading-relaxed font-mono"
                  ></textarea>
                </div>

                <div className="flex justify-end gap-3 pt-3">
                  <button
                    type="button"
                    onClick={() => {
                      setNewTitle("Heuristic Search (A*)");
                      setNewSubject("Artificial Intelligence");
                      setNewQText("Explain the A* search algorithm, defining its mathematical path cost evaluation function, and explain what is meant by an admissible heuristic.");
                      setNewModelAns("A* is a heuristic search algorithm that computes the path of lowest cost. It evaluates nodes using f(n) = g(n) + h(n), where g(n) is the exact cost from the start node to node n, and h(n) is the estimated cost from n to the goal. A heuristic h(n) is admissible if it never overestimates the actual cost to reach the goal. Admissibility guarantees that A* will find an optimal path.");
                      setNewRubricString("Define the A* search algorithm (pathfinding & optimization)\nExplain f(n) = g(n) + h(n) and define g(n) and h(n)\nDefine Admissibility (never overestimates the actual cost to goal)\nState that admissibility guarantees finding the optimal path");
                    }}
                    className="py-2 px-3 text-xs font-bold text-slate-500 hover:text-indigo-600 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-all uppercase tracking-wider"
                  >
                    Auto-Fill Demo
                  </button>
                  <button
                    type="submit"
                    className="py-2 px-4 text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg shadow-sm transition-all uppercase tracking-wider"
                  >
                    Create Question
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
