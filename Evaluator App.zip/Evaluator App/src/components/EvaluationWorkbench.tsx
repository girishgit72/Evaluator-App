import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  CheckCircle, 
  XCircle, 
  HelpCircle, 
  ChevronDown, 
  ChevronUp, 
  Sparkles, 
  BookOpen, 
  User, 
  Calendar, 
  Award, 
  Filter, 
  Search, 
  Plus, 
  AlertCircle,
  FileText
} from "lucide-react";

interface EvaluationWorkbenchProps {
  questions: any[];
  submissions: any[];
  onAddSubmission: (submission: { questionId: string; studentName: string; studentRoll: string; answerText: string }) => Promise<any>;
  onEvaluateSubmission: (id: string) => Promise<any>;
  activeSubmissionId?: string;
}

export default function EvaluationWorkbench({ 
  questions, 
  submissions, 
  onAddSubmission, 
  onEvaluateSubmission,
  activeSubmissionId 
}: EvaluationWorkbenchProps) {
  const [selectedSubId, setSelectedSubId] = useState<string | null>(activeSubmissionId || (submissions.length > 0 ? submissions[0].id : null));
  const [filterQuestion, setFilterQuestion] = useState<string>("all");
  const [filterStatus, setFilterStatus] = useState<string>("all"); // all, graded, pending
  const [searchQuery, setSearchQuery] = useState("");
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [evalStep, setEvalStep] = useState(0);
  
  // Modals / forms
  const [showAddForm, setShowAddForm] = useState(false);
  const [newSubName, setNewSubName] = useState("");
  const [newSubRoll, setNewSubRoll] = useState("");
  const [newSubQId, setNewSubQId] = useState(questions.length > 0 ? questions[0].id : "");
  const [newSubAnswer, setNewSubAnswer] = useState("");

  // Accordions for references
  const [showQuestionRef, setShowQuestionRef] = useState(true);
  const [showModelAnswerRef, setShowModelAnswerRef] = useState(false);

  // Selected submission
  const activeSub = submissions.find(s => s.id === selectedSubId) || (submissions.length > 0 ? submissions[0] : null);
  const activeQ = activeSub ? questions.find(q => q.id === activeSub.questionId) : null;

  // Filter submissions
  const filteredSubmissions = submissions.filter(sub => {
    const qMatches = filterQuestion === "all" || sub.questionId === filterQuestion;
    const statusMatches = filterStatus === "all" || 
      (filterStatus === "graded" && sub.evaluation) || 
      (filterStatus === "pending" && !sub.evaluation);
    const textMatches = sub.studentName.toLowerCase().includes(searchQuery.toLowerCase()) || 
      sub.studentRoll.toLowerCase().includes(searchQuery.toLowerCase());
    return qMatches && statusMatches && textMatches;
  });

  const evaluationSteps = [
    "Analyzing sentence semantic vectors...",
    "Computing cosine similarity with model answer concepts...",
    "Validating key criteria mapping in student response...",
    "Analyzing spelling, technical vocabulary, and grammatical structures...",
    "Synthesizing constructive coaching feedback metrics..."
  ];

  const triggerEvaluation = async () => {
    if (!activeSub) return;
    setIsEvaluating(true);
    setEvalStep(0);

    // Simulate stepping through diagnostic text
    const timer1 = setInterval(() => {
      setEvalStep(prev => (prev < evaluationSteps.length - 1 ? prev + 1 : prev));
    }, 1800);

    try {
      await onEvaluateSubmission(activeSub.id);
    } catch (err) {
      console.error(err);
    } finally {
      clearInterval(timer1);
      setIsEvaluating(false);
    }
  };

  const handleCreateSubmission = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSubName || !newSubRoll || !newSubQId || !newSubAnswer) return;
    
    try {
      const created = await onAddSubmission({
        questionId: newSubQId,
        studentName: newSubName,
        studentRoll: newSubRoll,
        answerText: newSubAnswer
      });
      setSelectedSubId(created.id);
      setShowAddForm(false);
      // Reset form
      setNewSubName("");
      setNewSubRoll("");
      setNewSubAnswer("");
    } catch (err) {
      console.error(err);
    }
  };

  // Helper to get similarity color
  const getSimilarityBadge = (score: number) => {
    if (score >= 85) return { text: "High Semantic Overlap", class: "bg-emerald-50 text-emerald-700 border-emerald-200" };
    if (score >= 60) return { text: "Moderate Semantic Overlap", class: "bg-amber-50 text-amber-700 border-amber-200" };
    return { text: "Low Semantic Overlap", class: "bg-rose-50 text-rose-700 border-rose-200" };
  };

  const getConceptScoreColor = (score: number) => {
    if (score >= 90) return "text-emerald-600 bg-emerald-50 border-emerald-100";
    if (score >= 60) return "text-amber-600 bg-amber-50 border-amber-100";
    return "text-rose-600 bg-rose-50 border-rose-100";
  };

  // Safe formatting of paragraph strings with simple bullets
  const renderTextContent = (text: string) => {
    if (!text) return null;
    return text.split("\n").map((para, i) => {
      if (para.trim().startsWith("-") || para.trim().startsWith("*")) {
        return (
          <li key={i} className="ml-4 list-disc text-slate-600 mb-1 leading-relaxed">
            {para.replace(/^[-*]\s*/, "")}
          </li>
        );
      }
      return (
        <p key={i} className="text-slate-600 mb-2 leading-relaxed text-sm">
          {para}
        </p>
      );
    });
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start" id="evaluation-workbench">
      
      {/* LEFT COLUMN: SIDEBAR LIST OF SUBMISSIONS */}
      <div className="lg:col-span-4 bg-white rounded-xl border border-slate-200 shadow-sm p-4 h-[750px] flex flex-col justify-between">
        <div className="space-y-4 flex-1 overflow-hidden flex flex-col">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
              <span className="w-1.5 h-3 bg-indigo-600 rounded-sm"></span>
              Submissions
            </h3>
            <button 
              onClick={() => setShowAddForm(true)}
              className="flex items-center gap-1 text-[11px] font-bold px-2.5 py-1.5 bg-indigo-600 text-white rounded hover:bg-indigo-700 transition-all shadow-xs uppercase tracking-wider"
            >
              <Plus className="h-3 w-3" />
              Add Test
            </button>
          </div>

          {/* Search and Filters */}
          <div className="space-y-2">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-400" />
              <input 
                type="text" 
                placeholder="Search student or roll..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-2">
              <div className="flex items-center gap-1 px-2.5 py-1.5 border border-slate-200 rounded-lg bg-slate-50/50">
                <Filter className="h-3 w-3 text-slate-400" />
                <select 
                  value={filterQuestion}
                  onChange={(e) => setFilterQuestion(e.target.value)}
                  className="w-full bg-transparent text-[10px] text-slate-600 focus:outline-none font-semibold"
                >
                  <option value="all">All Questions</option>
                  {questions.map(q => (
                    <option key={q.id} value={q.id}>{q.title}</option>
                  ))}
                </select>
              </div>

              <div className="flex items-center gap-1 px-2.5 py-1.5 border border-slate-200 rounded-lg bg-slate-50/50">
                <Award className="h-3 w-3 text-slate-400" />
                <select 
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="w-full bg-transparent text-[10px] text-slate-600 focus:outline-none font-semibold"
                >
                  <option value="all">All Status</option>
                  <option value="graded">Graded</option>
                  <option value="pending">Ungraded</option>
                </select>
              </div>
            </div>
          </div>

          {/* Submissions List */}
          <div className="flex-1 overflow-y-auto space-y-2 pr-1 mt-2">
            {filteredSubmissions.length > 0 ? (
              filteredSubmissions.map((sub) => {
                const isSelected = sub.id === selectedSubId;
                const q = questions.find(question => question.id === sub.questionId);
                return (
                  <button
                    key={sub.id}
                    onClick={() => {
                      if (!isEvaluating) setSelectedSubId(sub.id);
                    }}
                    disabled={isEvaluating}
                    className={`w-full text-left p-3.5 rounded-lg border transition-all duration-200 ${
                      isSelected 
                        ? "bg-slate-900 border-slate-900 text-white shadow-md" 
                        : "bg-slate-50/50 hover:bg-slate-50 border-slate-200 text-slate-800"
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wider ${
                          isSelected ? "bg-slate-800 text-slate-300 border border-slate-800/50" : "bg-slate-100 text-slate-500 border border-slate-200"
                        }`}>
                          {q?.subject || "Unknown"}
                        </span>
                        <h4 className={`text-xs font-bold mt-2 truncate ${isSelected ? "text-white" : "text-slate-900"}`}>
                          {sub.studentName}
                        </h4>
                      </div>
                      
                      {sub.evaluation ? (
                        <div className="text-right shrink-0">
                          <span className={`text-xs font-mono font-bold ${isSelected ? "text-indigo-300" : "text-indigo-600"}`}>
                            {sub.evaluation.score}/{q?.maxPoints || 10}
                          </span>
                          <span className={`block text-[9px] font-medium mt-0.5 ${isSelected ? "text-slate-400" : "text-slate-400"}`}>
                            Sim: {sub.evaluation.semanticSimilarityScore}%
                          </span>
                        </div>
                      ) : (
                        <span className="text-[9px] font-bold text-amber-600 bg-amber-50 border border-amber-100 px-1.5 py-0.5 rounded shrink-0">
                          Ungraded
                        </span>
                      )}
                    </div>
                    
                    <div className="flex items-center justify-between text-[10px] mt-2.5 text-slate-400 border-t border-slate-100/10 pt-1.5">
                      <span className="font-mono">ID: {sub.studentRoll}</span>
                      <span>{new Date(sub.submittedAt).toLocaleDateString()}</span>
                    </div>
                  </button>
                );
              })
            ) : (
              <div className="text-center py-16 text-xs text-slate-400 border border-dashed border-slate-200 rounded-lg bg-slate-50/50">
                No submissions found matching criteria.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* RIGHT COLUMN: EVALUATION WORKBENCH PANE */}
      <div className="lg:col-span-8 space-y-6">
        {activeSub ? (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
            
            {/* Split A: Student Answer & References (5 columns) */}
            <div className="md:col-span-6 space-y-4">
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-5">
                {/* Student Profile */}
                <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-full bg-slate-50 text-slate-600 border border-slate-200">
                      <User className="h-4 w-4" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-slate-900">{activeSub.studentName}</h3>
                      <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-0.5">
                        <span>Roll: <span className="font-mono font-bold text-slate-600">{activeSub.studentRoll}</span></span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <span className="text-[9px] text-slate-400 block uppercase font-bold tracking-wider">Submitted</span>
                    <div className="flex items-center gap-1 text-[11px] text-slate-500 mt-0.5 font-medium">
                      <Calendar className="h-3.5 w-3.5" />
                      <span>{new Date(activeSub.submittedAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>

                {/* Question and Accordions */}
                <div className="space-y-3">
                  {/* Active Question Box */}
                  <div className="p-4 rounded-lg border border-indigo-100 bg-indigo-50/10">
                    <span className="text-[9px] font-bold text-indigo-600 uppercase tracking-widest bg-indigo-50 border border-indigo-100 px-1.5 py-0.5 rounded">{activeQ?.subject}</span>
                    <h4 className="text-xs font-bold text-slate-900 mt-2">{activeQ?.title}</h4>
                    <p className="text-xs text-slate-600 mt-1.5 leading-relaxed font-medium">{activeQ?.questionText}</p>
                  </div>

                  {/* Model Answer Accordion */}
                  <div className="border border-slate-200 rounded-lg overflow-hidden bg-slate-50/30">
                    <button 
                      onClick={() => setShowModelAnswerRef(!showModelAnswerRef)}
                      className="w-full flex items-center justify-between px-4 py-2.5 text-xs font-bold text-slate-700 hover:bg-slate-50 transition-all border-b border-transparent"
                    >
                      <span className="flex items-center gap-1.5">
                        <BookOpen className="h-3.5 w-3.5 text-slate-500" />
                        Model Answer & Rubric
                      </span>
                      {showModelAnswerRef ? <ChevronUp className="h-4 w-4 text-slate-400" /> : <ChevronDown className="h-4 w-4 text-slate-400" />}
                    </button>
                    {showModelAnswerRef && activeQ && (
                      <div className="p-4 bg-white border-t border-slate-200 space-y-3 text-xs text-slate-600 leading-relaxed">
                        <div>
                          <span className="font-bold text-slate-800 block mb-1 uppercase tracking-wider text-[10px]">Answer Benchmark:</span>
                          <p className="bg-slate-50 p-2.5 rounded border border-slate-100 font-medium">{activeQ.modelAnswer}</p>
                        </div>
                        <div className="pt-3 border-t border-slate-100">
                          <span className="font-bold text-slate-800 block mb-1.5 uppercase tracking-wider text-[10px]">Rubric Criteria Items:</span>
                          <ul className="space-y-1.5 list-disc pl-4 text-[11px] font-medium text-slate-600">
                            {activeQ.rubricCriteria.map((rc: string, i: number) => (
                              <li key={i}>{rc}</li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Actual Answer Text Area */}
                <div className="space-y-2 pt-2 border-t border-slate-150">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-850 flex items-center gap-1.5">
                      <FileText className="h-4 w-4 text-indigo-500" />
                      Student Descriptive Response
                    </span>
                    <span className="text-[10px] font-mono text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200">
                      {activeSub.answerText.split(/\s+/).filter(Boolean).length} words
                    </span>
                  </div>
                  <div className="p-4 rounded-lg border border-slate-200 bg-slate-50/50 text-slate-700 text-xs font-sans leading-relaxed select-text min-h-[220px] max-h-[350px] overflow-y-auto">
                    {renderTextContent(activeSub.answerText)}
                  </div>
                </div>
              </div>
            </div>

            {/* Split B: AI Evaluation Report (6 columns) */}
            <div className="md:col-span-6">
              <AnimatePresence mode="wait">
                {isEvaluating ? (
                  /* IMMERSIVE AI LOADING STATE */
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    className="bg-slate-900 text-white rounded-2xl border border-slate-800 shadow-xl p-8 flex flex-col items-center justify-center text-center h-[620px]"
                  >
                    <div className="relative mb-8">
                      <motion.div 
                        animate={{ rotate: 360 }}
                        transition={{ repeat: Infinity, duration: 8, ease: "linear" }}
                        className="w-20 h-20 rounded-full border-2 border-dashed border-indigo-400/40 border-t-indigo-400"
                      ></motion.div>
                      <Sparkles className="h-8 w-8 text-indigo-400 absolute top-6 left-6 animate-pulse" />
                    </div>
                    
                    <h3 className="text-lg font-bold text-white flex items-center gap-2">
                      Gemini 3.5-Flash
                    </h3>
                    <p className="text-xs text-slate-400 mt-1 max-w-xs">Performing Automated NLP Evaluation and Semantic Similarity Assessment.</p>

                    <div className="mt-8 bg-slate-800/80 rounded-xl p-4 w-full max-w-sm border border-slate-700/50 min-h-[85px] flex items-center justify-center">
                      <motion.div 
                        key={evalStep}
                        initial={{ opacity: 0, y: 5 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="text-xs font-medium text-indigo-200 flex items-center gap-2"
                      >
                        <span className="inline-block w-2 h-2 rounded-full bg-indigo-400 animate-ping"></span>
                        {evaluationSteps[evalStep]}
                      </motion.div>
                    </div>

                    <div className="mt-6 text-[10px] text-slate-500 font-mono">
                      Request ID: sside-gemini-eval-{activeSub.id}
                    </div>
                  </motion.div>
                ) : activeSub.evaluation ? (
                  /* DETAILED AI EVALUATION REPORT */
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-slate-900 text-slate-100 rounded-xl border border-slate-800 shadow-2xl p-6 space-y-6 relative overflow-hidden"
                  >
                    {/* Decorative geometric circle */}
                    <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
                      <div className="w-48 h-48 border-[12px] border-white rounded-full"></div>
                    </div>

                    {/* Header Score Block */}
                    <div className="flex flex-col sm:flex-row items-center justify-between gap-4 border-b border-slate-800 pb-5 relative z-10">
                      <div className="flex items-center gap-4">
                        {/* Radial score box */}
                        <div className="h-16 w-16 rounded-xl bg-slate-800 border border-slate-700 text-indigo-400 flex flex-col items-center justify-center shrink-0 shadow-inner">
                          <span className="text-2xl font-bold font-mono leading-none">{activeSub.evaluation.score}</span>
                          <span className="text-[9px] font-bold text-slate-400 mt-1 uppercase">/ {activeQ?.maxPoints || 10} pts</span>
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="text-sm font-bold text-white uppercase tracking-wider">Evaluation Report</h3>
                            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 uppercase tracking-widest">AI</span>
                          </div>
                          <div className="flex items-center gap-1.5 text-xs text-slate-400 mt-1.5">
                            <Award className="h-4 w-4 text-emerald-400" />
                            <span>Grade: <span className="font-bold text-white">{activeSub.evaluation.score >= (activeQ?.maxPoints || 10) * 0.8 ? "Pass (Excellent)" : "Needs Review"}</span></span>
                          </div>
                        </div>
                      </div>

                      {/* Overlap Badge */}
                      <span className={`text-[10px] font-bold uppercase tracking-wider px-3 py-1.5 rounded-full border ${
                        activeSub.evaluation.semanticSimilarityScore >= 80 
                          ? "bg-emerald-950/40 text-emerald-300 border-emerald-800/50" 
                          : activeSub.evaluation.semanticSimilarityScore >= 50 
                          ? "bg-amber-950/40 text-amber-300 border-amber-800/50" 
                          : "bg-rose-950/40 text-rose-300 border-rose-800/50"
                      }`}>
                        {getSimilarityBadge(activeSub.evaluation.semanticSimilarityScore).text}
                      </span>
                    </div>

                    {/* Dynamic Similarity Progress Area */}
                    <div className="flex items-center gap-4 bg-slate-850 p-4 rounded-lg border border-slate-800 relative z-10">
                      <div className="flex-1">
                        <div className="text-[9px] text-slate-400 uppercase font-bold tracking-wider mb-1.5">Semantic NLP Similarity</div>
                        <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                          <div className="h-full bg-gradient-to-r from-indigo-500 to-emerald-400 rounded-full" style={{ width: `${activeSub.evaluation.semanticSimilarityScore}%` }}></div>
                        </div>
                      </div>
                      <div className="text-xl font-bold text-white font-mono">{activeSub.evaluation.semanticSimilarityScore}%</div>
                    </div>

                    {/* Criteria-by-Criteria Breakdown */}
                    <div className="space-y-3 relative z-10">
                      <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Rubric Criteria Scores</h4>
                      <div className="space-y-2.5 max-h-[190px] overflow-y-auto pr-1">
                        {activeSub.evaluation.conceptCoverage.map((cc: any, idx: number) => (
                          <div key={idx} className="p-3 rounded-lg border border-slate-800 bg-slate-850/50 space-y-1 hover:border-slate-750 transition-all">
                            <div className="flex items-start justify-between gap-4">
                              <span className="text-xs font-bold text-slate-200 leading-tight">{cc.concept}</span>
                              <span className={`text-[10px] font-bold font-mono px-1.5 py-0.5 rounded border shrink-0 bg-slate-800 text-indigo-300 border-slate-700/50`}>
                                {cc.score}%
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-400 leading-relaxed mt-1 font-medium">{cc.feedback}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Strengths & Weaknesses (Split Tag lists) */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-800 relative z-10">
                      {/* Strengths */}
                      <div className="space-y-2">
                        <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                          <CheckCircle className="h-3.5 w-3.5" /> Key Strengths
                        </span>
                        <div className="space-y-1.5">
                          {activeSub.evaluation.strengths.map((str: string, i: number) => (
                            <div key={i} className="text-[11px] text-emerald-200 bg-emerald-950/20 border border-emerald-900/30 p-2.5 rounded-lg leading-relaxed font-medium">
                              {str}
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Weaknesses */}
                      <div className="space-y-2">
                        <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                          <XCircle className="h-3.5 w-3.5" /> Identified Gaps
                        </span>
                        <div className="space-y-1.5">
                          {activeSub.evaluation.weaknesses.map((weak: string, i: number) => (
                            <div key={i} className="text-[11px] text-amber-200 bg-amber-950/20 border border-amber-900/30 p-2.5 rounded-lg leading-relaxed font-medium">
                              {weak}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Constructive coaching feedback */}
                    <div className="pt-4 border-t border-slate-800 space-y-1.5 relative z-10">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">AI Feedback & Remediation Guidance</span>
                      <div className="p-4 rounded-lg bg-slate-850 text-xs text-slate-300 leading-relaxed border border-slate-800 font-medium">
                        {renderTextContent(activeSub.evaluation.constructiveFeedback)}
                      </div>
                    </div>

                    {/* Metadata Footer */}
                    <div className="flex items-center justify-between text-[10px] text-slate-500 pt-3 border-t border-slate-800 relative z-10">
                      <span>Grammar Accuracy: <span className="font-bold text-slate-400 font-mono">{activeSub.evaluation.grammarScore}%</span></span>
                      <span>Graded at {new Date(activeSub.evaluation.evaluatedAt).toLocaleTimeString()}</span>
                    </div>
                  </motion.div>
                ) : (
                  /* UNGRADED/PENDING STATE */
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="bg-slate-50 border border-dashed border-slate-300 rounded-xl p-8 flex flex-col items-center justify-center text-center h-[550px] space-y-5 shadow-inner"
                  >
                    <div className="p-4 rounded-full bg-white text-indigo-600 border border-slate-200 shadow-sm animate-bounce">
                      <Sparkles className="h-6 w-6" />
                    </div>
                    <div className="space-y-1.5">
                      <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">Evaluation Required</h3>
                      <p className="text-xs text-slate-500 max-w-sm mx-auto leading-relaxed font-medium">
                        This student's descriptive response is ready to be evaluated using semantic analysis, keyword synonym matching, and AI rubrics.
                      </p>
                    </div>

                    <button
                      onClick={triggerEvaluation}
                      className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider px-5 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg shadow-sm hover:shadow transition-all"
                    >
                      <Sparkles className="h-4 w-4" />
                      Run Semantic AI Grading
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

          </div>
        ) : (
          <div className="bg-white rounded-xl border border-slate-200 p-12 text-center text-slate-400 font-medium">
            No submissions loaded. Use the left sidebar to add a test student.
          </div>
        )}
      </div>

      {/* CREATE SUBMISSION MODAL FORM */}
      <AnimatePresence>
        {showAddForm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-xl border border-slate-200 shadow-2xl max-w-xl w-full overflow-hidden flex flex-col"
            >
              <div className="p-6 border-b border-slate-150 flex items-center justify-between bg-slate-50">
                <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">Add Student Answer Submission</h3>
                <button 
                  onClick={() => setShowAddForm(false)}
                  className="text-xs text-slate-400 hover:text-slate-600 font-bold uppercase tracking-wider"
                >
                  Cancel
                </button>
              </div>
              
              <form onSubmit={handleCreateSubmission} className="p-6 space-y-4 flex-1">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Student Name</label>
                    <input 
                      type="text"
                      placeholder="e.g. Liam Foster"
                      required
                      value={newSubName}
                      onChange={(e) => setNewSubName(e.target.value)}
                      className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/10 focus:border-indigo-500"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Roll / ID Number</label>
                    <input 
                      type="text"
                      placeholder="e.g. CS2026-045"
                      required
                      value={newSubRoll}
                      onChange={(e) => setNewSubRoll(e.target.value)}
                      className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/10 focus:border-indigo-500 font-mono"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Select Examination Question</label>
                  <select
                    value={newSubQId}
                    onChange={(e) => setNewSubQId(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/10 focus:border-indigo-500 font-medium text-slate-700"
                  >
                    {questions.map(q => (
                      <option key={q.id} value={q.id}>[{q.subject}] {q.title}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Student's Descriptive Answer Text</label>
                    <span className="text-[10px] text-slate-400 font-medium">Descriptive paragraph</span>
                  </div>
                  <textarea
                    rows={8}
                    required
                    placeholder="Type the descriptive student response here. You can write correct, partially correct, or incorrect answers to test the semantic similarity analysis..."
                    value={newSubAnswer}
                    onChange={(e) => setNewSubAnswer(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/10 focus:border-indigo-500 leading-relaxed font-sans"
                  ></textarea>
                </div>

                <div className="flex justify-end gap-3 pt-3">
                  <button
                    type="button"
                    onClick={() => {
                      // Seed a good, partially correct answer
                      if (newSubQId === "q-dbms-acid") {
                        setNewSubAnswer("ACID properties are Atomic, Consitent, and Durable. Isolation is skipped here. Consistency means it checks key constraints. Durability means records are written to safe storage to avoid resets in financial apps. Atomicity means a transaction is done as a whole.");
                      } else if (newSubQId === "q-phys-newton3") {
                        setNewSubAnswer("Newton's 3rd law states that for every action force there is an opposite reaction. It does not cancel out. The rocket burns fuel and pushes down, which makes the rocket lift off because of the reaction force.");
                      } else {
                        setNewSubAnswer("Genetic flow is DNA -> RNA -> Protein. Transcription creates mRNA from DNA. Translation is done in the ribosome which combines proteins.");
                      }
                    }}
                    className="py-2 px-3 text-xs font-bold text-slate-500 hover:text-indigo-600 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-all uppercase tracking-wider"
                  >
                    Auto-Fill Demo Text
                  </button>
                  <button
                    type="submit"
                    className="py-2 px-4 text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg shadow-sm transition-all uppercase tracking-wider"
                  >
                    Submit Answer
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
