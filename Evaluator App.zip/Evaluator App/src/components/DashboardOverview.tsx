import { motion } from "motion/react";
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  Cell 
} from "recharts";
import { 
  BookOpen, 
  FileCheck, 
  Clock, 
  Award, 
  LineChart, 
  TrendingUp, 
  AlertTriangle,
  ArrowRight
} from "lucide-react";

interface DashboardOverviewProps {
  stats: {
    overview: {
      totalQuestions: number;
      totalSubmissions: number;
      gradedSubmissions: number;
      pendingSubmissions: number;
      averageScorePct: number;
      averageSimilarity: number;
    };
    questionTrends: any[];
    subjectStats: any[];
  } | null;
  submissions: any[];
  questions: any[];
  onNavigateToTab: (tab: string, activeId?: string) => void;
}

export default function DashboardOverview({ stats, submissions, questions, onNavigateToTab }: DashboardOverviewProps) {
  if (!stats) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  const { overview, questionTrends, subjectStats } = stats;

  // Identify lowest scoring rubric concepts across all graded questions
  const conceptGaps = questionTrends
    .flatMap(q => q.conceptAverages.map((ca: any) => ({
      ...ca,
      questionTitle: q.questionTitle,
      subject: q.subject,
      questionId: q.questionId
    })))
    .sort((a, b) => a.averageScore - b.averageScore)
    .slice(0, 4); // top 4 lowest scoring concepts

  return (
    <div className="space-y-8" id="dashboard-overview">
      {/* Metrics Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-5">
        {[
          {
            id: "metric-questions",
            title: "Total Questions",
            value: overview.totalQuestions,
            subtitle: "Descriptive Rubrics Active",
            icon: BookOpen,
            color: "text-indigo-600 bg-indigo-50",
            dotColor: "bg-indigo-500",
          },
          {
            id: "metric-submissions",
            title: "Total Submissions",
            value: overview.totalSubmissions,
            subtitle: `${overview.pendingSubmissions} Pending Evaluation`,
            icon: FileCheck,
            color: "text-indigo-600 bg-indigo-50",
            dotColor: "bg-purple-500",
          },
          {
            id: "metric-graded",
            title: "Graded Answers",
            value: overview.gradedSubmissions,
            subtitle: `${Math.round((overview.gradedSubmissions / (overview.totalSubmissions || 1)) * 100)}% Completed`,
            icon: Clock,
            color: "text-emerald-600 bg-emerald-50",
            dotColor: "bg-green-500",
          },
          {
            id: "metric-avg-score",
            title: "Class Average",
            value: `${overview.averageScorePct}%`,
            subtitle: "Overall Grade Metric",
            icon: Award,
            color: "text-purple-600 bg-purple-50",
            dotColor: "bg-indigo-600",
          },
          {
            id: "metric-similarity",
            title: "Avg Semantic Match",
            value: `${overview.averageSimilarity}%`,
            subtitle: "Text Semantic Overlap",
            icon: LineChart,
            color: "text-pink-600 bg-pink-50",
            dotColor: "bg-pink-500",
          },
        ].map((item, idx) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.05 }}
            className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between"
          >
            <div className="flex justify-between items-start mb-2">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{item.title}</span>
              <div className={`w-2 h-2 ${item.dotColor} rounded-full`}></div>
            </div>
            <div className="text-3xl font-bold text-slate-900 tracking-tight my-1">{item.value}</div>
            <div className="text-[11px] text-slate-500 font-medium mt-1">{item.subtitle}</div>
            <div className="h-1 bg-slate-100 rounded-full overflow-hidden mt-3">
              <div 
                className={`h-full bg-indigo-600 transition-all duration-500`} 
                style={{ width: typeof item.value === 'number' ? `${Math.min(item.value * 10, 100)}%` : `${parseFloat(item.value) || 75}%` }}
              ></div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Question Performance Benchmark Chart */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-1">
              <h3 className="text-sm font-bold text-slate-900 tracking-tight">Question Performance Benchmark</h3>
              <div className="flex items-center space-x-2 text-[10px] font-bold uppercase tracking-wider text-slate-500">
                <span className="inline-block w-2.5 h-2.5 bg-indigo-600 rounded-sm"></span>
                <span>Score %</span>
                <span className="inline-block w-2.5 h-2.5 bg-pink-400 rounded-sm"></span>
                <span>Semantic Overlap %</span>
              </div>
            </div>
            <p className="text-[11px] text-slate-500 mb-6 font-medium">Comparing students' absolute grade percentage with AI-calculated semantic similarity against model answers.</p>
          </div>
          
          <div className="h-80 w-full text-xs">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={questionTrends.map(q => ({
                  name: q.questionTitle.length > 20 ? q.questionTitle.substring(0, 18) + "..." : q.questionTitle,
                  "Score %": Math.round((q.averageScore / q.maxPoints) * 100),
                  "Semantic Overlap %": q.averageSemanticSimilarity
                }))}
                margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="name" tickLine={false} axisLine={false} stroke="#64748b" />
                <YAxis domain={[0, 100]} tickLine={false} axisLine={false} stroke="#64748b" />
                <Tooltip 
                  contentStyle={{ backgroundColor: "#0f172a", borderRadius: "8px", border: "none", color: "#f8fafc" }}
                  labelStyle={{ fontWeight: "bold", color: "#94a3b8" }}
                />
                <Bar dataKey="Score %" fill="#4f46e5" radius={[2, 2, 0, 0]} barSize={16} />
                <Bar dataKey="Semantic Overlap %" fill="#ec4899" radius={[2, 2, 0, 0]} barSize={16} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Subject Performance & Submissions Breakdown */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900 tracking-tight mb-1">Subject Performance Averages</h3>
            <p className="text-[11px] text-slate-500 mb-6 font-medium">Normalized average student grades clustered by disciplinary subject area.</p>
          </div>
          
          <div className="h-80 w-full text-xs">
            {subjectStats.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={subjectStats} layout="vertical" margin={{ top: 10, right: 10, left: 10, bottom: 10 }}>
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e2e8f0" />
                  <XAxis type="number" domain={[0, 100]} tickLine={false} axisLine={false} stroke="#64748b" />
                  <YAxis type="category" dataKey="subject" tickLine={false} axisLine={false} stroke="#64748b" width={110} />
                  <Tooltip
                    contentStyle={{ backgroundColor: "#0f172a", borderRadius: "8px", border: "none", color: "#f8fafc" }}
                  />
                  <Bar dataKey="averageScorePct" radius={[0, 2, 2, 0]} barSize={14}>
                    {subjectStats.map((entry, index) => {
                      const colors = ["#4f46e5", "#06b6d4", "#f59e0b", "#10b981"];
                      return <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />;
                    })}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex items-center justify-center h-full text-slate-400">No graded content available yet.</div>
            )}
          </div>
        </div>
      </div>

      {/* Concept Gaps & Class Remediation Recommendations (Critical User Prompt requirement) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Concept Gaps Breakdown */}
        <div className="lg:col-span-2 bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-amber-500" />
                Key Concept Gaps (Lowest Rubric Averages)
              </h3>
              <p className="text-[11px] text-slate-500 mt-0.5 font-medium">Specific conceptual criteria where the class scored lowest across descriptive responses.</p>
            </div>
            <span className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-amber-50 text-amber-700 uppercase tracking-wider">Action Required</span>
          </div>

          <div className="space-y-4">
            {conceptGaps.length > 0 ? (
              conceptGaps.map((item, idx) => (
                <div key={`${item.questionId}-${idx}`} className="p-4 rounded-xl border border-slate-100 bg-slate-50/50 flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <span className="text-[9px] font-bold uppercase tracking-wider text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded">{item.subject}</span>
                    <h4 className="text-xs font-bold text-slate-800 mt-1">{item.concept}</h4>
                    <p className="text-[11px] text-slate-500">From question: <span className="font-semibold text-slate-600">{item.questionTitle}</span></p>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 block font-semibold uppercase">Class Avg</span>
                      <span className="text-xs font-bold font-mono text-amber-600 bg-amber-50 border border-amber-100 px-1.5 py-0.5 rounded">{item.averageScore}%</span>
                    </div>
                    <button 
                      onClick={() => onNavigateToTab("questions", item.questionId)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-white border border-transparent hover:border-slate-200 transition-all shadow-sm"
                      title="Adjust Instructional Strategy"
                    >
                      <ArrowRight className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-10 text-slate-400">All concept averages look robust!</div>
            )}
          </div>
        </div>

        {/* Recent Submissions Feed */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900 mb-4">Recent Submissions</h3>
            <div className="space-y-4 max-h-[280px] overflow-y-auto pr-1">
              {submissions.slice(-4).reverse().map((sub) => {
                const q = questions.find(question => question.id === sub.questionId);
                return (
                  <div key={sub.id} className="text-xs border-b border-slate-100 pb-3 last:border-0 last:pb-0">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-slate-800">{sub.studentName}</span>
                      {sub.evaluation ? (
                        <span className="font-mono font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-100">
                          {sub.evaluation.score}/{q?.maxPoints || 10}
                        </span>
                      ) : (
                        <span className="text-[10px] font-bold text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-100">
                          Ungraded
                        </span>
                      )}
                    </div>
                    <div className="text-slate-500 text-[11px] truncate mb-1">Q: {q?.title || "Unknown Question"}</div>
                    <div className="flex items-center justify-between text-[10px] text-slate-400">
                      <span className="font-mono">{sub.studentRoll}</span>
                      <button 
                        onClick={() => onNavigateToTab("workbench", sub.id)}
                        className="text-indigo-600 hover:underline flex items-center gap-1 font-semibold"
                      >
                        {sub.evaluation ? "View Report" : "Grade Now"}
                        <ArrowRight className="h-2.5 w-2.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          
          <button
            onClick={() => onNavigateToTab("workbench")}
            className="w-full mt-4 py-2.5 text-center text-xs font-bold text-indigo-600 hover:text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-100 rounded-lg transition-all"
          >
            Go to Grading Workbench
          </button>
        </div>
      </div>
    </div>
  );
}
